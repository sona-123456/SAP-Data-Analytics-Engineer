"""
SAP ERP — Production Planning Module
Plan-to-Produce: Full Manufacturing Order Cycle Simulation
PIR → MRP → Prod. Order → GI → Confirmation → GR → Settlement

Company  : KIIT Industries Ltd.  |  Plant: 1000 — Mfg. Unit, BBSR
Student  : Sonali  |  Roll: 23051302  |  B.Tech CSE 2023–2027, KIIT University
"""

import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


# ══════════════════════════════════════════════════════════════
# ENUMS
# ══════════════════════════════════════════════════════════════

class OrderStatus(Enum):
    CREATED           = "Created"
    RELEASED          = "Released"
    PART_CONFIRMED    = "Partially Confirmed"
    FULLY_CONFIRMED   = "Fully Confirmed"
    TECH_COMPLETE     = "Technically Complete"
    SETTLED           = "Settled"


# ══════════════════════════════════════════════════════════════
# MASTER DATA  — mirrors SPRO / MM01 / CS01 / CA01 / C223
# ══════════════════════════════════════════════════════════════

COMPANY_CODE  = "1000"
COMPANY_NAME  = "KIIT Industries Ltd."
PLANT         = "1000"
PLANT_DESC    = "Mfg. Unit, BBSR"
STORAGE_LOC   = "0001"
FISCAL_YEAR   = "FY 2024-25"

# Material cost rates (moving-average price / standard price)
# RM-A : ₹120 / kg,  RM-B : ₹30 / pc
RM_PRICE = {
    "RM-A": 120.0,   # ₹ per kg
    "RM-B":  30.0,   # ₹ per pcs
}

# Work-center activity rates
ACTIVITY_RATES = {
    "machine_hrs": 500.0,   # ₹ per machine hour
    "labour_hrs":  300.0,   # ₹ per labour hour
}

OVERHEAD_RATE = 0.11        # 11 % applied on (RM + activity) costs

# BOM for FG-001  (CS01)
# FG-001 = 10 kg RM-A  +  5 pcs RM-B  per unit produced
BOM: Dict[str, Dict[str, dict]] = {
    "FG-001": {
        "RM-A": {"qty": 10, "unit": "kg",  "desc": "Raw Aluminium Block"},
        "RM-B": {"qty":  5, "unit": "pcs", "desc": "Steel Fasteners"},
    }
}

# Routing activity per unit confirmed  (CA01)
ROUTING_ACTIVITY = {
    "machine_hrs": 0.25,   # 0.25 hrs / unit
    "labour_hrs":  0.20,   # 0.20 hrs / unit
}

ROUTING_STEPS = ["Machining", "Assembly", "Quality Check", "Painting", "Packaging"]

# Warehouse stock (MB52)
STOCK: Dict[str, float] = {
    "FG-001": 0,
    "RM-A":   5_000,   # kg
    "RM-B":   3_000,   # pcs
}

# Work-centre utilisation  (CM01 / OS01)
WORK_CENTERS = {
    "WC-MACH01":  {"name": "Machining",     "utilisation": 87},
    "WC-ASSY01":  {"name": "Assembly",       "utilisation": 73},
    "WC-QC01":    {"name": "Quality Check",  "utilisation": 61},
    "WC-PAINT01": {"name": "Painting",       "utilisation": 55},
    "WC-PACK01":  {"name": "Packaging",      "utilisation": 68},
}

# Document number counters
_COUNTERS = {"MAT": 4_500_000, "PROD": 1_000, "PIR": 100, "SETTLE": 5_000}

def _next(doc_type: str) -> str:
    _COUNTERS[doc_type] += 1
    return f"{doc_type}{_COUNTERS[doc_type]}"


# ══════════════════════════════════════════════════════════════
# DISPLAY HELPERS
# ══════════════════════════════════════════════════════════════

W = 72

def hr(ch="─"): print(ch * W)
def banner(t):  print(); hr("═"); print(f"  {t}"); hr("═")
def section(t): print(); hr(); print(f"  {t}"); hr()
def cur(v):     return f"₹{v:,.2f}"
def tc(code):   return f"[T-Code: {code}]"


# ══════════════════════════════════════════════════════════════
# DATA MODELS
# ══════════════════════════════════════════════════════════════

@dataclass
class PIR:
    """Planned Independent Requirement  — MD61"""
    pir_no:    str
    material:  str
    plant:     str
    quantity:  int
    period:    str
    created:   datetime.date = field(default_factory=datetime.date.today)

    def show(self):
        print(f"  PIR No   : {self.pir_no}")
        print(f"  Material : {self.material}")
        print(f"  Plant    : {self.plant} — {PLANT_DESC}")
        print(f"  Qty      : {self.quantity} units")
        print(f"  Period   : {self.period}")
        print(f"  Date     : {self.created}")


@dataclass
class PlannedOrder:
    """MRP-generated Planned Order — MD01"""
    order_no:    str
    material:    str
    quantity:    int
    start_date:  datetime.date
    finish_date: datetime.date
    components:  Dict[str, float] = field(default_factory=dict)   # mat → qty needed

    def show(self):
        print(f"  Planned Order : {self.order_no}")
        print(f"  Material      : {self.material}")
        print(f"  Qty           : {self.quantity} units")
        print(f"  Dates         : {self.start_date}  →  {self.finish_date}")
        if self.components:
            print(f"  Components    :")
            for mat, qty in self.components.items():
                unit = BOM["FG-001"][mat]["unit"]
                print(f"    {mat} : {qty:.0f} {unit}")


@dataclass
class ProductionOrder:
    """Production Order — CO01"""
    order_no:     str
    material:     str
    plant:        str
    quantity:     int
    status:       OrderStatus
    planned_cost: float = 0.0
    actual_cost:  float = 0.0          # accumulates through GI → Conf → Overhead
    created:      datetime.date = field(default_factory=datetime.date.today)
    released:     Optional[datetime.date] = None

    # Cost components accumulated during execution
    _actual_rm:       float = field(default=0.0, repr=False)
    _actual_machine:  float = field(default=0.0, repr=False)
    _actual_labour:   float = field(default=0.0, repr=False)
    _actual_overhead: float = field(default=0.0, repr=False)

    def show(self):
        print(f"  Production Order : {self.order_no}")
        print(f"  Material         : {self.material}")
        print(f"  Plant            : {self.plant} — {PLANT_DESC}")
        print(f"  Quantity         : {self.quantity} units")
        print(f"  Status           : {self.status.value}")
        print(f"  Planned Cost     : {cur(self.planned_cost)}")
        print(f"  Actual Cost      : {cur(self.actual_cost)}")
        if self.released:
            print(f"  Released         : {self.released}")


@dataclass
class MaterialDocument:
    """Material Document from MIGO"""
    doc_no:       str
    mv_type:      int          # 261 = GI, 101 = GR
    material:     str
    quantity:     float
    unit:         str
    sloc:         str
    amount:       float
    posting_date: datetime.date
    order_ref:    str

    def show(self):
        desc = {261: "Goods Issue — Component Consumption",
                101: "Goods Receipt — Finished Goods"}[self.mv_type]
        print(f"  Mat. Doc     : {self.doc_no}")
        print(f"  Mvt Type     : {self.mv_type}  ({desc})")
        print(f"  Material     : {self.material}")
        print(f"  Quantity     : {self.quantity:.0f} {self.unit}")
        print(f"  Storage Loc  : {self.sloc}")
        print(f"  Amount       : {cur(self.amount)}")
        print(f"  Posting Date : {self.posting_date}")
        print(f"  Prod. Order  : {self.order_ref}")


@dataclass
class Confirmation:
    """Production Confirmation — CO11N"""
    conf_no:       str
    order_no:      str
    confirmed_qty: int
    scrap_qty:     int
    machine_hrs:   float
    labour_hrs:    float
    machine_cost:  float
    labour_cost:   float
    posting_date:  datetime.date

    @property
    def activity_cost(self):
        return self.machine_cost + self.labour_cost

    def show(self):
        print(f"  Confirmation No : {self.conf_no}")
        print(f"  Order No        : {self.order_no}")
        print(f"  Confirmed Qty   : {self.confirmed_qty} units")
        print(f"  Scrap Qty       : {self.scrap_qty} units")
        print(f"  Machine Hrs     : {self.machine_hrs:.2f} hrs  @ {cur(ACTIVITY_RATES['machine_hrs'])}/hr"
              f"  = {cur(self.machine_cost)}")
        print(f"  Labour Hrs      : {self.labour_hrs:.2f} hrs  @ {cur(ACTIVITY_RATES['labour_hrs'])}/hr"
              f"  = {cur(self.labour_cost)}")
        print(f"  Total Activity  : {cur(self.activity_cost)}")
        print(f"  Posting Date    : {self.posting_date}")


@dataclass
class SettlementDocument:
    """Order Settlement — KO88"""
    doc_no:          str
    order_no:        str
    planned_cost:    float
    actual_cost:     float
    variance:        float
    variance_pct:    float
    settlement_rule: str
    fiscal_period:   str
    posting_date:    datetime.date

    def show(self):
        sign = "+" if self.variance >= 0 else ""
        print(f"  Settlement Doc  : {self.doc_no}")
        print(f"  Order No        : {self.order_no}")
        print(f"  Planned Cost    : {cur(self.planned_cost)}")
        print(f"  Actual Cost     : {cur(self.actual_cost)}")
        print(f"  Variance        : {sign}{cur(self.variance)}  ({sign}{self.variance_pct:.2f}%)")
        print(f"  Settlement Rule : {self.settlement_rule}")
        print(f"  Fiscal Period   : {self.fiscal_period}")
        print(f"  Posting Date    : {self.posting_date}")


# ══════════════════════════════════════════════════════════════
# COST CALCULATION HELPERS
# ══════════════════════════════════════════════════════════════

def _calc_planned_cost(qty: int) -> tuple:
    """
    Returns (rm_cost, machine_cost, labour_cost, overhead, total)
    for a given production quantity — used for the standard cost estimate.

    RM cost:      sum over each BOM component of (bom_qty * qty * price)
    Machine cost: routing_hrs_per_unit * qty * machine_rate
    Labour cost:  routing_hrs_per_unit * qty * labour_rate
    Overhead:     11 % of (RM + machine + labour)
    """
    rm_cost = sum(
        BOM["FG-001"][mat]["qty"] * qty * RM_PRICE[mat]
        for mat in BOM["FG-001"]
    )
    machine_cost = ROUTING_ACTIVITY["machine_hrs"] * qty * ACTIVITY_RATES["machine_hrs"]
    labour_cost  = ROUTING_ACTIVITY["labour_hrs"]  * qty * ACTIVITY_RATES["labour_hrs"]
    overhead     = (rm_cost + machine_cost + labour_cost) * OVERHEAD_RATE
    total        = rm_cost + machine_cost + labour_cost + overhead
    return rm_cost, machine_cost, labour_cost, overhead, total


# ══════════════════════════════════════════════════════════════
# STAGE 1 — DEMAND PLANNING  (MD61)
# ══════════════════════════════════════════════════════════════

def stage1_demand_planning(material: str, quantity: int, period: str) -> PIR:
    section(f"STAGE 1 — Demand Planning  {tc('MD61')}")
    print("  Entering Planned Independent Requirement (PIR) for Finished Goods...\n")
    pir = PIR(pir_no=_next("PIR"), material=material, plant=PLANT,
              quantity=quantity, period=period)
    pir.show()
    print(f"\n  ✔  PIR {pir.pir_no} saved — MRP flagged for next planning run.")
    return pir


# ══════════════════════════════════════════════════════════════
# STAGE 2 — MRP RUN  (MD01)
# ══════════════════════════════════════════════════════════════

def stage2_mrp_run(pir: PIR) -> List[PlannedOrder]:
    section(f"STAGE 2 — MRP Run  {tc('MD01')}")
    print(f"  MRP Type: PD  |  Lot Size: EX  |  Lead-time scheduling: ACTIVE")
    print(f"  Scope: Plant {PLANT}  |  Material: {pir.material}  |  Demand Qty: {pir.quantity} units\n")

    today       = datetime.date.today()
    components  = {mat: BOM[pir.material][mat]["qty"] * pir.quantity
                   for mat in BOM.get(pir.material, {})}

    po = PlannedOrder(order_no=_next("PROD"), material=pir.material,
                      quantity=pir.quantity,
                      start_date=today,
                      finish_date=today + datetime.timedelta(days=5),
                      components=components)

    print("  ► Planned Order generated for Finished Good:")
    po.show()

    print("\n  ► Component Coverage Check (MD04 — Stock/Requirements List):")
    print(f"  {'Material':<8} {'Required':>10} {'On-Hand':>10} {'Shortage':>10}  Result")
    hr("-")
    for mat, qty_req in components.items():
        on_hand = STOCK.get(mat, 0)
        shortage = max(0.0, qty_req - on_hand)
        unit = BOM[pir.material][mat]["unit"]
        result = ("✔ Covered by stock"
                  if shortage == 0
                  else f"⚠  Short {shortage:.0f} {unit} — Purchase Req. raised")
        print(f"  {mat:<8} {qty_req:>9.0f}{unit[0]:1}  {on_hand:>9.0f}{unit[0]:1}  "
              f"{shortage:>9.0f}{unit[0]:1}  {result}")

    print(f"\n  ✔  MRP run complete — planned order {po.order_no} created.")
    return [po]


# ══════════════════════════════════════════════════════════════
# STAGE 3 — CONVERT TO PRODUCTION ORDER  (CO01)
# ══════════════════════════════════════════════════════════════

def stage3_create_production_order(planned_order: PlannedOrder) -> ProductionOrder:
    section(f"STAGE 3 — Convert to Production Order  {tc('CO01')}")
    print(f"  Converting Planned Order {planned_order.order_no} → Production Order...\n")

    rm, mach, lab, ovhd, total = _calc_planned_cost(planned_order.quantity)

    prod_order = ProductionOrder(
        order_no=_next("PROD"),
        material=planned_order.material,
        plant=PLANT,
        quantity=planned_order.quantity,
        status=OrderStatus.RELEASED,
        planned_cost=total,
        released=datetime.date.today(),
    )
    prod_order.show()

    print(f"\n  Standard Cost Estimate (per order qty = {planned_order.quantity} units):")
    print(f"  {'Item':<30} {'Amount':>14}")
    hr("-")
    print(f"  {'Raw Material (RM-A + RM-B)':<30} {cur(rm):>14}")
    print(f"  {'Machine Hrs (0.25 hr/unit)':<30} {cur(mach):>14}")
    print(f"  {'Labour Hrs  (0.20 hr/unit)':<30} {cur(lab):>14}")
    print(f"  {'Overhead (11% of direct)':<30} {cur(ovhd):>14}")
    hr("-")
    print(f"  {'TOTAL PLANNED COST':<30} {cur(total):>14}")

    print(f"\n  ✔  Production Order {prod_order.order_no} released. "
          f"Cost object created in SAP CO.")
    return prod_order


# ══════════════════════════════════════════════════════════════
# STAGE 4 — GOODS ISSUE — Components  (MIGO 261)
# ══════════════════════════════════════════════════════════════

def stage4_goods_issue(prod_order: ProductionOrder) -> List[MaterialDocument]:
    section(f"STAGE 4 — Goods Issue (Components)  {tc('MIGO 261')}")
    print(f"  Issuing BOM components from Storage Location {STORAGE_LOC}"
          f" to Production Order {prod_order.order_no}...\n")

    mat_docs = []
    today    = datetime.date.today()

    for mat, info in BOM.get(prod_order.material, {}).items():
        qty_req  = info["qty"] * prod_order.quantity
        unit     = info["unit"]
        on_hand  = STOCK.get(mat, 0)

        if on_hand < qty_req:
            print(f"  ⚠  Stock shortfall for {mat}: "
                  f"Available={on_hand:.0f} {unit}, Required={qty_req:.0f} {unit}")
            qty_issued = on_hand
        else:
            qty_issued = qty_req

        # Actual cost = quantity issued × moving-average price
        amount = qty_issued * RM_PRICE[mat]
        STOCK[mat] -= qty_issued

        # Accumulate on order
        prod_order._actual_rm  += amount
        prod_order.actual_cost += amount

        doc = MaterialDocument(doc_no=_next("MAT"), mv_type=261, material=mat,
                               quantity=qty_issued, unit=unit, sloc=STORAGE_LOC,
                               amount=amount, posting_date=today,
                               order_ref=prod_order.order_no)
        mat_docs.append(doc)
        print(f"  ► Mat. Doc for {mat}:")
        doc.show()
        print()

    print(f"  Cumulative Actual Cost after GI : {cur(prod_order.actual_cost)}")
    print(f"\n  ✔  Goods Issue complete — RM costs posted to Production Order.")
    return mat_docs


# ══════════════════════════════════════════════════════════════
# STAGE 5 — PRODUCTION CONFIRMATION  (CO11N)
# ══════════════════════════════════════════════════════════════

def stage5_production_confirmation(prod_order: ProductionOrder) -> Confirmation:
    section(f"STAGE 5 — Production Confirmation  {tc('CO11N')}")
    print(f"  Posting shop-floor confirmation for Order {prod_order.order_no}...\n")

    # 97.5 % yield  →  2.5 % scrap (5 units on 200)
    confirmed_qty = int(prod_order.quantity * 0.975)
    scrap_qty     = prod_order.quantity - confirmed_qty

    # Actual activity = routing hrs/unit × confirmed qty
    machine_hrs  = round(ROUTING_ACTIVITY["machine_hrs"] * confirmed_qty, 2)
    labour_hrs   = round(ROUTING_ACTIVITY["labour_hrs"]  * confirmed_qty, 2)
    machine_cost = machine_hrs * ACTIVITY_RATES["machine_hrs"]
    labour_cost  = labour_hrs  * ACTIVITY_RATES["labour_hrs"]

    # Overhead on actual direct costs (RM already posted + activity now)
    overhead = (prod_order._actual_rm + machine_cost + labour_cost) * OVERHEAD_RATE

    # Accumulate on order
    prod_order._actual_machine  = machine_cost
    prod_order._actual_labour   = labour_cost
    prod_order._actual_overhead = overhead
    prod_order.actual_cost     += machine_cost + labour_cost + overhead
    prod_order.status           = OrderStatus.FULLY_CONFIRMED

    conf = Confirmation(conf_no=_next("PROD"), order_no=prod_order.order_no,
                        confirmed_qty=confirmed_qty, scrap_qty=scrap_qty,
                        machine_hrs=machine_hrs, labour_hrs=labour_hrs,
                        machine_cost=machine_cost, labour_cost=labour_cost,
                        posting_date=datetime.date.today())
    conf.show()

    print(f"\n  Overhead posted   : {cur(overhead)}  "
          f"(11% × actual RM + activity)")
    print(f"\n  Routing Steps Confirmed:")
    for i, step in enumerate(ROUTING_STEPS, 1):
        print(f"    {i}. {step}  ✔")

    print(f"\n  Cumulative Actual Cost after Confirmation : {cur(prod_order.actual_cost)}")
    print(f"\n  ✔  Confirmation posted — Activity & overhead costs booked to order.")
    return conf


# ══════════════════════════════════════════════════════════════
# STAGE 6 — GOODS RECEIPT — Finished Goods  (MIGO 101)
# ══════════════════════════════════════════════════════════════

def stage6_goods_receipt(prod_order: ProductionOrder,
                         confirmation: Confirmation) -> MaterialDocument:
    section(f"STAGE 6 — Goods Receipt (Finished Goods)  {tc('MIGO 101')}")
    print(f"  Receiving confirmed qty into Storage Location {STORAGE_LOC}...\n")

    # GR is valued at STANDARD COST per unit (from planned estimate)
    std_cost_per_unit = prod_order.planned_cost / prod_order.quantity
    gr_value          = std_cost_per_unit * confirmation.confirmed_qty

    STOCK["FG-001"] += confirmation.confirmed_qty

    doc = MaterialDocument(doc_no=_next("MAT"), mv_type=101,
                           material=prod_order.material,
                           quantity=confirmation.confirmed_qty,
                           unit="units", sloc=STORAGE_LOC,
                           amount=gr_value,
                           posting_date=datetime.date.today(),
                           order_ref=prod_order.order_no)
    doc.show()

    print(f"\n  Standard cost / unit        : {cur(std_cost_per_unit)}")
    print(f"  GR value (std × {confirmation.confirmed_qty} units) : {cur(gr_value)}")
    print(f"  Updated FG Stock (Sloc 0001): {STOCK['FG-001']} units")

    prod_order.status = OrderStatus.TECH_COMPLETE
    print(f"\n  ✔  Goods Receipt posted — FI/CO accounting document generated.")
    return doc


# ══════════════════════════════════════════════════════════════
# STAGE 7 — ORDER SETTLEMENT  (KO88)
# ══════════════════════════════════════════════════════════════

def stage7_order_settlement(prod_order: ProductionOrder) -> SettlementDocument:
    section(f"STAGE 7 — Order Settlement  {tc('KO88')}")
    print(f"  Settling Production Order {prod_order.order_no}...\n")

    variance     = prod_order.actual_cost - prod_order.planned_cost
    variance_pct = (variance / prod_order.planned_cost) * 100

    settle = SettlementDocument(
        doc_no=_next("SETTLE"),
        order_no=prod_order.order_no,
        planned_cost=prod_order.planned_cost,
        actual_cost=prod_order.actual_cost,
        variance=variance,
        variance_pct=variance_pct,
        settlement_rule="100% CO-PA",
        fiscal_period=FISCAL_YEAR,
        posting_date=datetime.date.today(),
    )
    settle.show()

    # Detailed variance breakdown
    rm_plan   = sum(BOM["FG-001"][m]["qty"] * prod_order.quantity * RM_PRICE[m]
                    for m in BOM["FG-001"])
    mach_plan = ROUTING_ACTIVITY["machine_hrs"] * prod_order.quantity * ACTIVITY_RATES["machine_hrs"]
    lab_plan  = ROUTING_ACTIVITY["labour_hrs"]  * prod_order.quantity * ACTIVITY_RATES["labour_hrs"]
    ovhd_plan = (rm_plan + mach_plan + lab_plan) * OVERHEAD_RATE

    print(f"\n  Variance Breakdown:")
    print(f"  {'Category':<20} {'Planned':>14} {'Actual':>14} {'Δ':>12}")
    hr("-")
    rows = [
        ("Raw Material",  rm_plan,   prod_order._actual_rm),
        ("Machine Hrs",   mach_plan, prod_order._actual_machine),
        ("Labour Hrs",    lab_plan,  prod_order._actual_labour),
        ("Overhead",      ovhd_plan, prod_order._actual_overhead),
    ]
    for cat, plan, actual in rows:
        delta = actual - plan
        sign  = "+" if delta >= 0 else ""
        print(f"  {cat:<20} {cur(plan):>14} {cur(actual):>14} {sign+cur(delta):>12}")
    hr("-")
    total_delta = prod_order.actual_cost - prod_order.planned_cost
    sign = "+" if total_delta >= 0 else ""
    print(f"  {'TOTAL':<20} {cur(prod_order.planned_cost):>14} "
          f"{cur(prod_order.actual_cost):>14} {sign+cur(total_delta):>12}")

    tolerance = "✔ Within ±3% tolerance"
    if abs(variance_pct) > 3.0:
        tolerance = ("⚠ OVERSPEND — review material/activity prices"
                     if variance_pct > 0 else
                     "⚠ UNDERSPEND — verify all cost postings")

    print(f"\n  Variance Assessment : {tolerance}")
    prod_order.status = OrderStatus.SETTLED
    print(f"\n  ✔  Settlement document {settle.doc_no} posted. Order status: SETTLED.")
    return settle


# ══════════════════════════════════════════════════════════════
# ANALYTICS REPORTS
# ══════════════════════════════════════════════════════════════

def report_order_status():
    section("REPORT — Production Order Status Overview  (COOIS) — FY 2024-25")
    data = [("Created", 12), ("Released", 45), ("Partially Confirmed", 18),
            ("Fully Confirmed", 62), ("Tech. Complete", 53), ("Settled", 49)]
    total = sum(c for _, c in data)
    print(f"  {'Status':<25} {'Count':>6}  {'Bar'}")
    hr("-")
    for status, count in data:
        bar = "█" * (count // 2)
        print(f"  {status:<25} {count:>6}  {bar}")
    print(f"\n  Total Orders: {total}")


def report_cost_distribution():
    section("REPORT — Production Cost Distribution  (CO03)")
    data = [("Raw Material", 0.52), ("Machine Hrs", 0.18),
            ("Labour Hrs",   0.14), ("Overhead",    0.11), ("Scrap", 0.05)]
    print(f"  {'Category':<18} {'  %':>6}  {'Bar'}")
    hr("-")
    for cat, pct in data:
        bar = "█" * int(pct * 60)
        print(f"  {cat:<18} {pct*100:>5.1f}%  {bar}")


def report_mrp_coverage():
    section("REPORT — MRP Component Coverage  (MD04 — Stock/Requirements List)")
    data = [("On-Hand Stock", 38.0), ("Planned Orders", 29.0),
            ("Purch. Reqs",   21.0), ("Safety Stock",    8.0), ("Shortage", 4.0)]
    print(f"  {'Coverage Type':<18} {'  %':>6}  {'Bar'}")
    hr("-")
    for cat, pct in data:
        bar = "█" * int(pct / 2)
        print(f"  {cat:<18} {pct:>5.1f}%  {bar}")


def report_work_centers():
    section("REPORT — Work Center Capacity Utilisation  (OS01 / CM01) — FY 2024-25")
    print(f"  {'WC ID':<14} {'Name':<18} {'Util %':>7}  {'Status'}")
    hr("-")
    for wc_id, info in WORK_CENTERS.items():
        u = info["utilisation"]
        bar = "█" * (u // 5)
        flag = ("🔴 CRITICAL (≥85%)" if u >= 85 else
                "🟡 WARNING  (≥70%)" if u >= 70 else "🟢 OK")
        print(f"  {wc_id:<14} {info['name']:<18} {u:>6}%  {flag}  {bar}")
    print("\n  Reference lines — Warning: 70%  |  Critical: 85%")


def report_planned_vs_actual():
    section("REPORT — Monthly Planned vs Actual GR Quantity  (MB52 / COOIS) — FY 2024-25")
    months  = ["Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec","Jan","Feb","Mar"]
    planned = [180, 195, 210, 220, 225, 220, 228, 235, 240, 242, 248, 255]
    actual  = [175, 200, 205, 222, 218, 225, 224, 232, 237, 244, 245, 258]
    print(f"  {'Month':<6} {'Planned':>9} {'Actual':>9} {'Delta':>8}  {'Trend'}")
    hr("-")
    for m, p, a in zip(months, planned, actual):
        d = a - p
        sign = "+" if d >= 0 else ""
        trend = "▲" if d > 0 else ("▼" if d < 0 else "─")
        print(f"  {m:<6} {p:>9} {a:>9} {sign+str(d):>8}  {trend}")


def report_cost_variance(settle: SettlementDocument):
    section("REPORT — Production Order Cost Variance  (KO88 / KKBC_ORD) — Q4 FY 2024-25")
    # Historical orders from report, plus the live one
    historical = {"PO-001": +4.3, "PO-002": -3.5, "PO-003": +2.7,
                  "PO-004": +3.8, "PO-005": -1.2, "PO-006": +4.9,
                  "PO-007": -2.1, "PO-008": +3.1}
    print(f"  {'Order':<12} {'Variance %':>11}  {'Assessment'}")
    hr("-")
    for po, var in historical.items():
        sign = "+" if var >= 0 else ""
        ok   = "✔ Within ±3%" if abs(var) <= 3.0 else "⚠ Exceeds ±3% limit"
        print(f"  {po:<12} {sign+str(var)+' %':>11}  {ok}")
    hr("-")
    sign = "+" if settle.variance_pct >= 0 else ""
    ok   = "✔ Within ±3%" if abs(settle.variance_pct) <= 3.0 else "⚠ Exceeds ±3% limit"
    label = f"{settle.order_no} (live)"
    print(f"  {label:<12} {sign+f'{settle.variance_pct:.2f} %':>11}  {ok}")


def report_stock_summary():
    section("REPORT — Current Warehouse Stock  (MB52 — Warehouse Stocks of Material)")
    print(f"  {'Material':<10} {'Description':<28} {'Qty':>10}  Unit")
    hr("-")
    info = {
        "FG-001": ("Finished Product FG-001",    STOCK["FG-001"], "units"),
        "RM-A":   ("Raw Aluminium Block",         STOCK["RM-A"],   "kg"),
        "RM-B":   ("Steel Fasteners",             STOCK["RM-B"],   "pcs"),
    }
    for mat, (desc, qty, unit) in info.items():
        print(f"  {mat:<10} {desc:<28} {qty:>10.0f}  {unit}")


def report_config_log():
    section("CONFIGURATION LOG — SPRO Setup (T-Codes used in this project)")
    rows = [
        ("OX02", "Define Company Code",    f"{COMPANY_CODE} — {COMPANY_NAME}"),
        ("OX10", "Create Plant",            f"{PLANT} — {PLANT_DESC}"),
        ("OX09", "Create Storage Location", f"{STORAGE_LOC} — Main Warehouse"),
        ("OS01", "Create Work Center",      "WC-MACH01 — Machining (500 ₹/hr)"),
        ("CA01", "Create Routing",          "Routing-FG001: Machining→Assembly→QC→Painting→Packaging"),
        ("CS01", "Create BOM",              "FG-001: RM-A (10 kg @ ₹120) + RM-B (5 pcs @ ₹30)"),
        ("C223", "Production Version",      "PV-001 — links BOM + Routing for FG-001"),
        ("MM01", "Material Master (FG)",    "FG-001: MRP type PD, lot size EX, std price"),
        ("MM01", "Material Master (RM)",    "RM-A, RM-B: MRP type PD, moving avg price"),
    ]
    print(f"  {'T-Code':<8} {'Config Step':<30} Value / Setting")
    hr("-")
    for tc_val, step, val in rows:
        print(f"  {tc_val:<8} {step:<30} {val}")


# ══════════════════════════════════════════════════════════════
# MAIN — FULL PLAN-TO-PRODUCE EXECUTION
# ══════════════════════════════════════════════════════════════

def main():
    banner(f"SAP ERP — PRODUCTION PLANNING (PP)  |  {COMPANY_NAME}")
    print(f"  Plant : {PLANT} — {PLANT_DESC}  |  Storage Loc : {STORAGE_LOC}  |  {FISCAL_YEAR}")
    print(f"  Cycle : PIR → MRP → Prod.Order → GI → Confirmation → GR → Settlement")
    print(f"  Student : Sonali  |  Roll : 23051302  |  B.Tech CSE 2023-2027  |  KIIT University")

    # ── Pre-run configuration log
    report_config_log()

    # ── STAGE 1 : Demand Planning
    pir = stage1_demand_planning("FG-001", quantity=200, period="April 2025")

    # ── STAGE 2 : MRP Run
    planned_orders = stage2_mrp_run(pir)

    # ── STAGE 3 : Convert to Production Order
    prod_order = stage3_create_production_order(planned_orders[0])

    # ── STAGE 4 : Goods Issue
    gi_docs = stage4_goods_issue(prod_order)

    # ── STAGE 5 : Production Confirmation
    confirmation = stage5_production_confirmation(prod_order)

    # ── STAGE 6 : Goods Receipt
    gr_doc = stage6_goods_receipt(prod_order, confirmation)

    # ── STAGE 7 : Order Settlement
    settlement = stage7_order_settlement(prod_order)

    # ── Analytics
    banner("DATA ANALYTICS & SAP STANDARD REPORTS")
    report_order_status()
    report_cost_distribution()
    report_mrp_coverage()
    report_work_centers()
    report_planned_vs_actual()
    report_cost_variance(settlement)
    report_stock_summary()

    # ── Final summary table
    banner("END-TO-END CYCLE SUMMARY — PLAN-TO-PRODUCE")
    print(f"  {'#':<3} {'T-Code':<12} {'Document':<14} Key Output")
    hr("-")
    summary = [
        (1, "MD61",     pir.pir_no,
         f"PIR — {pir.quantity} units {pir.material} for {pir.period}"),
        (2, "MD01",     planned_orders[0].order_no,
         f"Planned Order — FG + component requirements"),
        (3, "CO01",     prod_order.order_no,
         f"Production Order released — Planned Cost {cur(prod_order.planned_cost)}"),
        (4, "MIGO 261", gi_docs[0].doc_no,
         f"Goods Issue — RM-A & RM-B consumed from WH {STORAGE_LOC}"),
        (5, "CO11N",    confirmation.conf_no,
         f"{confirmation.confirmed_qty} units confirmed, "
         f"{confirmation.machine_hrs} mach-hrs, {confirmation.scrap_qty} scrap"),
        (6, "MIGO 101", gr_doc.doc_no,
         f"GR: {confirmation.confirmed_qty} units FG-001 into stock"),
        (7, "KO88",     settlement.doc_no,
         f"Variance {'+' if settlement.variance_pct>=0 else ''}"
         f"{settlement.variance_pct:.2f}% — Order SETTLED"),
    ]
    for s, t, doc, out in summary:
        print(f"  {s:<3} {t:<12} {doc:<14} {out}")

    print()
    hr("═")
    print(f"  ✔  All 7 stages executed successfully with correct cost flow.")
    print(f"  ✔  Final Stock  →  FG-001: {STOCK['FG-001']} units  |  "
          f"RM-A: {STOCK['RM-A']:.0f} kg  |  RM-B: {STOCK['RM-B']:.0f} pcs")
    print(f"  ✔  Order Status : {prod_order.status.value}")
    print(f"  ✔  Actual Cost  : {cur(prod_order.actual_cost)}")
    print(f"  ✔  Planned Cost : {cur(prod_order.planned_cost)}")
    sign = "+" if settlement.variance_pct >= 0 else ""
    print(f"  ✔  Variance     : {sign}{settlement.variance_pct:.2f}%")
    hr("═")
    print(f"  KIIT University, Bhubaneswar  |  B.Tech CSE  |  Batch 2023–2027")
    hr("═")


if __name__ == "__main__":
    main()
